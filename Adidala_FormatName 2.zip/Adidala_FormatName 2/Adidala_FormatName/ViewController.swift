//
//  ViewController.swift
//  Adidala_FormatName
//
//  Created by Adidala,Sindhuja on 2/1/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    @IBOutlet weak var DetailsLabel: UILabel!
    override func viewDidLoad() {
       
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        //let Submit = UIButton()
        var firstName = firstNameTextField.text!
        var lastName = lastNameTextField.text!
        
        fullNameLabel.text = "Full Name: \(lastName), \(firstName)"
        initialsLabel.text = "initials: \(firstName[firstName.startIndex])\(lastName[lastName.startIndex])"
        DetailsLabel.text = "Details"
        
    }
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        firstNameTextField.text!=""
        lastNameTextField.text!=""
        fullNameLabel.text=""
        initialsLabel.text=""
        DetailsLabel.text=""
        
        firstNameTextField.becomeFirstResponder()
    }
    
}

